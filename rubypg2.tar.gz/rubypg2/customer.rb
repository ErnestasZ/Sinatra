class Customer
  attr_accessor :name, :surname, :age, :code

  def initialize(name:, surname:, age:, code:)
    @name = name
    @surname = surname
    @age = age
    @code = code
  end

  def create
    $pg.exec_params(sql_insert, sql_insert_params)
  end

  private

  def sql_insert
    "INSERT INTO customers(name, surname, age, code) VALUES($1,$2,$3,$4)"
  end

  def sql_insert_params
    [name, surname, age, code]
  end

end 